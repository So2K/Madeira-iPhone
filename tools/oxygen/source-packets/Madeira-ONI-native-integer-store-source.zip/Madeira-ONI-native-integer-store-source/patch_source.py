#!/usr/bin/env python3
"""Apply only the reviewed four-case edit to the exact public source pin."""
from pathlib import Path
import difflib
import hashlib
import json

ROOT = Path(__file__).resolve().parent
REL = 'build/ntdll-unix/signal_arm64_ios.c'
BASELINE_SHA = 'e4bddf4e67e5925653f22ff41372ddd4e0fec53a075ff9c9eefe4a7a3ba0879b'
BASELINE_BLOB = 'cc4aac60c55c56088230cdcaeb7be004e274681a'


def digest(data):
    return hashlib.sha256(data).hexdigest()


def blob(data):
    return hashlib.sha1(b'blob ' + str(len(data)).encode() + b'\0' + data).hexdigest()


def transform(data):
    if digest(data) != BASELINE_SHA or blob(data) != BASELINE_BLOB:
        raise ValueError('baseline source pin mismatch')
    source = data.decode()
    start = source.index('                    /* STR (immediate, post/pre-index, 64-bit):')
    end = source.index('                    /* SIMD/FP STR (immediate, post/pre-index, D-reg', start)
    target = source[start:end]
    for family in ('0xf8000000', '0xb8000000', '0x38000000', '0x78000000'):
        old = f'(insn & 0xffe00000) == {family} && (insn & 0x800) == 0'
        if target.count(old) != 1:
            raise ValueError('four-family predicate guard mismatch')
    if target.count('IOS_STORE_SRC(rt)') != 4:
        raise ValueError('four source-read guard mismatch')
    old_wb = 'state.__x[rn] = (uint64_t)((int64_t)state.__x[rn] + imm9);'
    if target.count(old_wb) != 4:
        raise ValueError('four writeback guard mismatch')
    target = target.replace('(insn & 0x800) == 0', '(insn & 0xc00) != 0x800')
    target = target.replace('IOS_STORE_SRC(rt)',
                            '(rt == 31 ? 0ULL : rt == 30 ? state.__lr : rt == 29 ? state.__fp : state.__x[rt])')
    indent = ' ' * 28
    new_wb = ('uint64_t base = rn == 31 ? state.__sp : rn == 30 ? state.__lr :\n'
              + indent + '                rn == 29 ? state.__fp : state.__x[rn];\n'
              + indent + 'uint64_t updated = base + (uint64_t)(int64_t)imm9;\n'
              + indent + 'if (rn == 31) state.__sp = updated;\n'
              + indent + 'else if (rn == 30) state.__lr = updated;\n'
              + indent + 'else if (rn == 29) state.__fp = updated;\n'
              + indent + 'else state.__x[rn] = updated;')
    target = target.replace(old_wb, new_wb)
    candidate = source[:start] + target + source[end:]
    assert candidate[:start] == source[:start]
    assert candidate[start + len(target):] == source[end:]
    return candidate.encode(), {'original_start_line': source[:start].count('\n') + 1,
                                'original_end_line': source[:end].count('\n')}


if __name__ == '__main__':
    baseline = (ROOT / 'upstream' / REL).read_bytes()
    candidate, span = transform(baseline)
    destination = ROOT / 'src' / REL
    destination.parent.mkdir(parents=True, exist_ok=True)
    destination.write_bytes(candidate)
    diff = ''.join(difflib.unified_diff(baseline.decode().splitlines(True), candidate.decode().splitlines(True),
                                      fromfile='a/' + REL, tofile='b/' + REL))
    (ROOT / 'integer-immediate-store.patch').write_text('diff --git a/' + REL + ' b/' + REL + '\n'
                                                      + f'index {blob(baseline)}..{blob(candidate)} 100644\n' + diff)
    report = {'scope': 'four integer-immediate cases only', 'baseline_sha256': digest(baseline),
              'baseline_git_blob': blob(baseline), 'sha256': digest(candidate), 'git_blob': blob(candidate),
              'bytes': len(candidate), 'span': span, 'predicate_changes': 4,
              'explicit_source_read_changes': 4, 'explicit_modular_writeback_changes': 4,
              'upstream_commit': 'c2c1b03a9e36ef986c980b9eae3c14d05a372db1',
              'source_url': 'https://github.com/willfaust/Madeira/blob/c2c1b03a9e36ef986c980b9eae3c14d05a372db1/' + REL,
              'native_or_PE_binary_rewritten': False}
    (ROOT / 'build/source-verification.json').write_text(json.dumps(report, indent=2) + '\n')
    print(json.dumps(report))
