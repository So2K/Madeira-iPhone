#!/usr/bin/env bash
set -euo pipefail
root=$(cd "$(dirname "$0")" && pwd)
python3 "$root/patch_source.py"
python3 "$root/tests/extract_cases.py"
python3 "$root/tests/run.py"
