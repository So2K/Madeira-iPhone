#!/usr/bin/env python3
"""Extract exact production predicates/bodies, without a hand-maintained decoder copy."""
from pathlib import Path
import hashlib
import json

ROOT = Path(__file__).resolve().parents[1]
REL = 'build/ntdll-unix/signal_arm64_ios.c'
FAMILIES = ('0xf8000000', '0xb8000000', '0x38000000', '0x78000000')


def extract(source):
    result = []
    for family in FAMILIES:
        marker = f'                    else if ((insn & 0xffe00000) == {family}'
        start = source.index(marker)
        end = source.index('\n                    }', start) + len('\n                    }')
        block = source[start:end]
        assert block.count('{') == block.count('}')
        if not result:
            block = block.replace('else if', 'if', 1)
        result.append(block)
    return '\n'.join(result)


reports = {}
for label, folder in (('baseline', 'upstream'), ('candidate', 'src')):
    data = (ROOT / folder / REL).read_bytes()
    cases = extract(data.decode())
    source = ('static int ' + label + '_execute(uint32_t insn, test_state *input, uintptr_t fault_addr)\n{\n'
              '    test_state state = *input;\n    int emulated = 0;\n    uintptr_t alias_fault = 0;\n'
              '    int honor_guest_prot = 1;\n' + cases
              + '\n    *input = state;\n    return emulated;\n}\n')
    (ROOT / 'build' / (label + '_cases.inc')).write_text(source)
    reports[label] = {'source_sha256': hashlib.sha256(data).hexdigest(),
                      'extracted_cases_sha256': hashlib.sha256(cases.encode()).hexdigest(),
                      'families': list(FAMILIES)}
(ROOT / 'build/extraction.json').write_text(json.dumps(reports, indent=2) + '\n')
