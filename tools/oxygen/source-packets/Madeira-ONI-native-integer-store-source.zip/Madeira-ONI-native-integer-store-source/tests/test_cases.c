/* SPDX-License-Identifier: LGPL-2.1-or-later
 * Host semantics tests; production handlers are extracted, never reimplemented here. */
#define __DARWIN_OPAQUE_ARM_THREAD_STATE64 0
#include <assert.h>
#include <inttypes.h>
#include <stddef.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#if defined(__APPLE__) && defined(__aarch64__)
#include <mach/arm/thread_status.h>
typedef arm_thread_state64_t test_state;
#define STATE_KIND "actual Darwin arm_thread_state64_t"
#else
typedef struct {
    uint64_t __x[29], __fp, __lr, __sp, __pc;
    uint32_t __cpsr, __pad;
} test_state;
#define STATE_KIND "Darwin-shaped 29+FP/LR/SP thread state"
#endif

_Static_assert(sizeof(((test_state *)0)->__x) / sizeof(uint64_t) == 29, "must not hide array bounds");
_Static_assert(offsetof(test_state, __fp) == 29 * sizeof(uint64_t), "FP layout");
_Static_assert(offsetof(test_state, __lr) == 30 * sizeof(uint64_t), "LR layout");
_Static_assert(offsetof(test_state, __sp) == 31 * sizeof(uint64_t), "SP layout");

struct capture {
    int succeeds;
    unsigned calls;
    uintptr_t addr;
    size_t bytes;
    uint8_t written[8];
} cap;
static uint64_t checked;

static int ios_alias_write(uintptr_t addr, const void *src, size_t size, uintptr_t *blocked, int honor)
{
    assert(honor == 1 && size >= 1 && size <= 8);
    assert(blocked && !*blocked);
    cap.calls++;
    cap.addr = addr;
    cap.bytes = size;
    if (!cap.succeeds) return 0;
    memcpy(cap.written, src, size);
    return 1;
}

/* This deliberately preserves the baseline's real macro and 29-element array. */
#define IOS_STORE_SRC(r) ((r) == 31 ? 0ULL : state.__x[r])
#include "../build/baseline_cases.inc"
#include "../build/candidate_cases.inc"

static uint64_t get_reg(const test_state *s, unsigned reg)
{
    if (reg == 29) return s->__fp;
    if (reg == 30) return s->__lr;
    if (reg == 31) return s->__sp;
    return s->__x[reg];
}
static void set_reg(test_state *s, unsigned reg, uint64_t value)
{
    if (reg == 29) s->__fp = value;
    else if (reg == 30) s->__lr = value;
    else if (reg == 31) s->__sp = value;
    else s->__x[reg] = value;
}
static test_state initial(void)
{
    test_state s;
    memset(&s, 0, sizeof(s));
    for (unsigned i = 0; i < 29; i++) s.__x[i] = UINT64_C(0xa55ac33cde008000) ^ ((uint64_t)i * UINT64_C(0x1020304050607));
    s.__fp = UINT64_C(0x2930293029302930);
    s.__lr = UINT64_C(0x3031303130313031);
    s.__sp = UINT64_C(0x7000004000);
    s.__pc = UINT64_C(0x140001000);
    s.__cpsr = 0xa0000000u;
    return s;
}
static uint32_t encode(unsigned lg2, unsigned mode, int offset, unsigned rn, unsigned rt)
{
    assert(lg2 < 4 && mode < 4 && offset >= -256 && offset <= 255 && rn < 32 && rt < 32);
    return UINT32_C(0x38000000) | (lg2 << 30) | (((uint32_t)offset & 511) << 12)
           | (mode << 10) | (rn << 5) | rt;
}

static void one(unsigned lg2, unsigned mode, int offset, unsigned rn, unsigned rt, uint64_t base, int succeeds)
{
    /* Writeback with Rn==Rt (except SP/ZR) is constrained-unpredictable. */
    if ((mode == 1 || mode == 3) && rn != 31 && rn == rt) return;
    test_state s = initial(), expected;
    set_reg(&s, rn, base);
    expected = s;
    const uint64_t operand = rt == 31 ? 0 : get_reg(&s, rt);
    const unsigned bytes = 1u << lg2;
    /* Independent architectural oracle: offset/pre use Rn+imm; post uses old Rn. */
    const uint64_t adjusted = base + (uint64_t)(int64_t)offset;
    const uint64_t effective = mode == 1 ? base : adjusted;
    const int supported = mode == 0 || mode == 1 || mode == 3;
    memset(&cap, 0, sizeof(cap));
    memset(cap.written, 0xa7, sizeof(cap.written));
    cap.succeeds = succeeds;
    const int result = candidate_execute(encode(lg2, mode, offset, rn, rt), &s, (uintptr_t)effective);
    if (supported && succeeds && (mode == 1 || mode == 3)) set_reg(&expected, rn, adjusted);
    assert(result == (supported && succeeds));
    assert(cap.calls == (unsigned)supported);
    assert(memcmp(&s, &expected, sizeof(s)) == 0);  /* including PC, NZCV and every untouched register */
    if (supported) assert(cap.addr == effective && cap.bytes == bytes);
    for (unsigned i = 0; i < sizeof(cap.written); i++)
        assert(cap.written[i] == (supported && succeeds && i < bytes ? (uint8_t)(operand >> (8 * i)) : 0xa7));
    checked++;
}

static void negative_encoding(uint32_t insn)
{
    test_state s = initial(), before = s;
    memset(&cap, 0, sizeof(cap));
    cap.succeeds = 1;
    assert(candidate_execute(insn, &s, 0x7000004000) == 0);
    assert(!cap.calls && memcmp(&before, &s, sizeof(s)) == 0);
    checked++;
}

int main(int argc, char **argv)
{
    if (argc == 2)
    {
        test_state s = initial();
        memset(&cap, 0, sizeof(cap));
        cap.succeeds = 1;
        if (!strcmp(argv[1], "--baseline-sp"))
            baseline_execute(encode(3, 1, 16, 31, 10), &s, (uintptr_t)s.__sp);
        else if (!strcmp(argv[1], "--baseline-fp-source"))
            baseline_execute(encode(3, 0, 0, 12, 29), &s, (uintptr_t)s.__x[12]);
        else if (!strcmp(argv[1], "--baseline-signed-overflow"))
        {
            s.__x[12] = (uint64_t)INT64_MAX - 7;
            baseline_execute(encode(3, 1, 56, 12, 10), &s, (uintptr_t)s.__x[12]);
        }
        else return 3;
        fputs("baseline UB regression unexpectedly survived sanitizers\n", stderr);
        return 4;
    }
    const uint16_t endian = 1;
    assert(*(const uint8_t *)&endian == 1);  /* actual target is little endian */
    assert(encode(1, 3, 56, 12, 10) == UINT32_C(0x78038d8a));
    /* Baseline decoder rejects each legal pre-index width and retains other mode classification. */
    for (unsigned lg2 = 0; lg2 < 4; lg2++)
        for (unsigned mode = 0; mode < 4; mode++)
        {
            test_state s = initial();
            memset(&cap, 0, sizeof(cap));
            cap.succeeds = 1;
            assert(baseline_execute(encode(lg2, mode, 0, 12, 10), &s, (uintptr_t)s.__x[12]) == (mode < 2));
            checked++;
        }
    /* Every imm9 bit pattern, every mode and width, including SP and source ZR. */
    for (unsigned lg2 = 0; lg2 < 4; lg2++)
        for (unsigned mode = 0; mode < 4; mode++)
            for (int imm = -256; imm <= 255; imm++)
            {
                one(lg2, mode, imm, 12, 10, UINT64_C(0x7000004000), 1);
                one(lg2, mode, imm, 31, 31, UINT64_C(0x7000004000), 1);
                one(lg2, mode, imm, 29, 30, UINT64_C(0x7000004000), 0);
            }
    const int offsets[] = {-256, -255, -8, -1, 0, 1, 8, 56, 255};
    const uint64_t bases[] = {UINT64_C(0x7000004000), 0, UINT64_MAX - 255,
                             (uint64_t)INT64_MAX - 127, (uint64_t)INT64_MIN + 128};
    for (unsigned lg2 = 0; lg2 < 4; lg2++)
        for (unsigned mode = 0; mode < 4; mode++)
            for (unsigned oi = 0; oi < sizeof(offsets) / sizeof(offsets[0]); oi++)
                for (unsigned rn = 0; rn < 32; rn++)
                    for (unsigned rt = 0; rt < 32; rt++)
                        for (unsigned bi = 0; bi < sizeof(bases) / sizeof(bases[0]); bi++)
                            for (int succeeds = 0; succeeds < 2; succeeds++)
                                one(lg2, mode, offsets[oi], rn, rt, bases[bi], succeeds);
    for (unsigned lg2 = 0; lg2 < 4; lg2++)
        for (unsigned mode = 0; mode < 4; mode++)
        {
            const uint32_t insn = encode(lg2, mode, 56, 12, 10);
            negative_encoding(insn | (1u << 22));  /* load */
            negative_encoding(insn | (1u << 26));  /* SIMD */
            negative_encoding(insn | (1u << 21));  /* register-offset family */
        }
    negative_encoding(0);
    printf("PASS: %" PRIu64 " extracted-production vectors; %s; all4 widths/modes, imm9, GPR/ZR/FP/LR/SP, write failure and modular boundaries\n",
           checked, STATE_KIND);
    return 0;
}
