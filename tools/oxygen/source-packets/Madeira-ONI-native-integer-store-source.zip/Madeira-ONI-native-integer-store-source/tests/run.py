#!/usr/bin/env python3
from pathlib import Path
import hashlib
import importlib.util
import json
import os
import shutil
import subprocess
import tempfile

ROOT = Path(__file__).resolve().parents[1]
BUILD = ROOT / 'build'
REL = 'build/ntdll-unix/signal_arm64_ios.c'


def run(args, **kwargs):
    return subprocess.run(args, cwd=ROOT, text=True, capture_output=True, **kwargs)


if shutil.disk_usage(ROOT).free < 576 * 1024 * 1024:
    raise SystemExit('bounded host-test scratch guard: less than 576 MiB free')
spec = importlib.util.spec_from_file_location('patch_source', ROOT / 'patch_source.py')
patch = importlib.util.module_from_spec(spec)
spec.loader.exec_module(patch)
baseline = (ROOT / 'upstream' / REL).read_bytes()
candidate = (ROOT / 'src' / REL).read_bytes()
assert patch.transform(baseline)[0] == candidate
negative_guards = 0
for offset in (0, 1, 32, len(baseline) // 2, len(baseline) - 1):
    damaged = bytearray(baseline)
    damaged[offset] ^= 1
    try:
        patch.transform(bytes(damaged))
    except ValueError:
        negative_guards += 1
    else:
        raise AssertionError('modified baseline accepted')

# The actual published diff must apply to the pinned original and produce the exact candidate.
with tempfile.TemporaryDirectory(prefix='apply-check-', dir=BUILD) as tmp:
    folder = Path(tmp)
    path = folder / REL
    path.parent.mkdir(parents=True)
    path.write_bytes(baseline)
    applied = subprocess.run(['git', 'apply', str(ROOT / 'integer-immediate-store.patch')],
                             cwd=folder, text=True, capture_output=True)
    assert applied.returncode == 0, applied.stderr
    assert path.read_bytes() == candidate

cc = os.environ.get('CC', 'clang')
exe = BUILD / 'test_cases'
flags = ['-std=gnu11', '-O1', '-g', '-Wall', '-Wextra', '-Werror', '-fsanitize=address,undefined',
         '-fno-sanitize-recover=all', '-fno-omit-frame-pointer']
compiled = run([cc, *flags, str(ROOT / 'tests/test_cases.c'), '-o', str(exe)])
(BUILD / 'compile.log').write_text(compiled.stdout + compiled.stderr)
assert compiled.returncode == 0, compiled.stderr
execution = run([str(exe)], timeout=60)
(BUILD / 'semantic.log').write_text(execution.stdout + execution.stderr)
assert execution.returncode == 0, execution.stdout + execution.stderr
controls = []
for option, fragment in (('--baseline-sp', 'index 31 out of bounds'),
                         ('--baseline-fp-source', 'index 29 out of bounds'),
                         ('--baseline-signed-overflow', 'signed integer overflow')):
    control = run([str(exe), option], timeout=15)
    (BUILD / (option[2:] + '.log')).write_text(control.stdout + control.stderr)
    assert control.returncode != 0 and fragment in control.stderr, (option, control.returncode, control.stderr)
    controls.append({'option': option, 'expected_diagnostic': fragment, 'observed': True,
                     'returncode': control.returncode})
report = {
    'scope': 'host extracted-production semantic tests; no native app or PE binary build',
    'baseline_sha256': hashlib.sha256(baseline).hexdigest(),
    'candidate_sha256': hashlib.sha256(candidate).hexdigest(),
    'candidate_bytes': len(candidate), 'sanitizers': ['address', 'undefined'],
    'compiler': run([cc, '--version']).stdout.splitlines()[0], 'flags': flags,
    'semantic_stdout': execution.stdout.strip(), 'semantic_returncode': execution.returncode,
    'production_extraction': json.loads((BUILD / 'extraction.json').read_text()),
    'baseline_UB_regression_controls': controls, 'baseline_negative_pin_guards': negative_guards,
    'published_git_diff_applies_to_exact_baseline': True,
    'native_app_compiled': False, 'forked_or_pushed': False, 'phone_or_signing_changed': False,
    'limits': ['Caller-supplied noncrossing effective FAR and alias-write callback are modeled, not real Mach exception delivery',
               'Writeback Rn==Rt except SP/ZR constrained-unpredictable encodings are excluded',
               'Other store families and global IOS_STORE_SRC macro remain unchanged',
               'No ONI runtime or FPS acceptance claim'],
}
(BUILD / 'test-report.json').write_text(json.dumps(report, indent=2) + '\n')
print(execution.stdout.strip())
print('PASS: exact diff application, 5 altered-baseline guards, 3 expected baseline UBSan regression controls')
