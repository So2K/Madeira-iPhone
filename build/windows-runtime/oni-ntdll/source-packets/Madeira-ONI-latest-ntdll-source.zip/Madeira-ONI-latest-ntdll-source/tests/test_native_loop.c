#include <assert.h>
#include <pthread.h>
#include <stdint.h>
#include <stdio.h>
extern uint64_t oni_original_loop(uint32_t *,uint32_t);
extern uint64_t oni_patched_loop(uint32_t *,uint32_t);
static uint32_t word;
enum { THREADS=4, ROUNDS=20000 };
static void *worker(void *v) {
    unsigned bit=(unsigned)(uintptr_t)v;
    uint32_t own=1u<<bit;
    uint64_t (*fn)(uint32_t*,uint32_t)=(bit&1)?oni_patched_loop:oni_original_loop;
    for(unsigned n=0;n<ROUNDS;n++) {
        assert(!(__atomic_fetch_or(&word,own,__ATOMIC_SEQ_CST)&own));
        uint64_t result=fn(&word,~own);
        assert(!(result>>32) && !((uint32_t)result&own));
        assert(!(__atomic_load_n(&word,__ATOMIC_SEQ_CST)&own));
    }
    return NULL;
}
int main(void) {
    uint32_t values[]={0,1,0x7fffffff,0x80000000,0xffffffff,0xdeadbeef};
    uint32_t masks[]={0,1,0xfffffffe,0x55555555,0xffffffff};
    unsigned vectors=0;
    for(unsigned a=0;a<sizeof(values)/4;a++) for(unsigned b=0;b<sizeof(masks)/4;b++) {
        uint32_t x=values[a],y=x;
        uint64_t r0=oni_original_loop(&x,masks[b]);
        uint64_t r1=oni_patched_loop(&y,masks[b]);
        assert(r0==r1 && x==y && y==(values[a]&masks[b]) && r1==y);
        vectors++;
    }
    pthread_t threads[THREADS];
    for(unsigned i=0;i<THREADS;i++) assert(!pthread_create(&threads[i],NULL,worker,(void*)(uintptr_t)i));
    for(unsigned i=0;i<THREADS;i++) assert(!pthread_join(threads[i],NULL));
    assert(!word);
    printf("PASS: real arm64 original/patched exact opcode loops; %u equivalent vector/live-out checks; %u threads x %u mixed-loop set/clear rounds\n",vectors,THREADS,ROUNDS);
}
