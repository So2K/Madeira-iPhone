#!/usr/bin/env python3
"""MIT. Guard regression tests; these do not simulate GPU/game performance."""
from pathlib import Path
import importlib.util
import json
import struct
root=Path(__file__).resolve().parents[1]
spec=importlib.util.spec_from_file_location('patch',root/'patch_ntdll.py')
m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
b=(root/'baseline/ntdll.dll').read_bytes()
count=0
def refused(label,data,deep=False):
    global count
    before=bytes(data)
    try:
        if deep:m.guards(bytes(data),check_hash=False)
        else:m.transform(bytes(data))
    except (m.GuardError,KeyError,ValueError,struct.error):pass
    else:raise AssertionError('Accepted bad input: '+label)
    assert bytes(data)==before,'Guard mutated rejected input'
    count+=1
def byte_case(label,offset,value,deep=False):
    x=bytearray(b);x[offset]=value;refused(label,x,deep)

result,report=m.transform(b);count+=1
assert [i for i,(a,c) in enumerate(zip(b,result)) if a!=c]==[0x28400,0x28404]
assert result[m.RVA:m.RVA+16]==m.NEW and len(result)==len(b)
again,_=m.transform(b);assert again==result;count+=1
refused('already-patched input',result)
refused('truncated baseline',b[:-1])
refused('extra byte',b+b'\0')
for label,offset,value in [('DOS',0,0),('PE offset',60,0xff),('machine',0x7c,0),('unrelated data',0x110010,b[0x110010]^1),('timestamp',0x80,b[0x80]^1),('wrong-load',m.RVA,0),('wrong-AND',m.RVA+4,0),('wrong-store',m.RVA+8,0),('wrong-retry',m.RVA+12,0)]:byte_case(label,offset,value)
# Bypass only the exact-hash gate, exercising independent contextual/structural guards.
for label,offset,value in [('changed neighbour',m.CONTEXT_RVA,b[m.CONTEXT_RVA]^1),('opcode',m.RVA,b[m.RVA]^1),('retry target',m.RVA+13,b[m.RVA+13]^1),('native owner thunk',0x90970,b[0x90970]^1)]:byte_case(label,offset,value,True)
pe=m.PE(b)
for label,offset,value in [('wrong-architecture-deep',pe.pe+4,0),('wrong-CHPE-version',pe.at(pe.architecture()['metadata_rva']),1),('section-count-overflow',pe.pe+6,255)]:byte_case(label,offset,value,True)
x=bytearray(b);struct.pack_into('<II',x,pe.opt+112+8,0xa0000,20);refused('unexpected imports',x,True)
# Export and native exception entry may not begin in the loop interior.
ep=pe.at(pe.dirs[0][0],40);funcs=struct.unpack_from('<I',b,ep+28)[0]
x=bytearray(b);struct.pack_into('<I',x,pe.at(funcs+4*(414-1),4),m.RVA+4);refused('owner export into interior',x,True)
x=bytearray(b);struct.pack_into('<I',x,pe.at(pe.architecture()['fields'][16],4),m.RVA+4);refused('unwind start into interior',x,True)
# Inject a real branch/ADR into native code; caught even with hash disabled.
for target in (m.RVA+4,m.RVA+8,m.RVA+12):
    x=bytearray(b);pc=0x11000;insn=0x14000000|(((target-pc)//4)&0x3ffffff)
    struct.pack_into('<I',x,pc,insn);refused('incoming interior branch',x,True)
    x=bytearray(b);delta=target-pc;imm=delta&0x1fffff
    struct.pack_into('<I',x,pc,0x10000000|((imm&3)<<29)|((imm>>2)<<5))
    refused('incoming interior ADR',x,True)
    x=bytearray(b);x[0x11000:0x11010]=m.OLD;refused('duplicate original loop',x,True)
check={'suite':'strict patch guards','checks':count,'pass':True,'baseline_sha256':m.sha(b),'candidate_sha256':m.sha(result),'only_two_byte_diff':True,'negative_inputs_not_mutated':True}
print(json.dumps(check,indent=2))
