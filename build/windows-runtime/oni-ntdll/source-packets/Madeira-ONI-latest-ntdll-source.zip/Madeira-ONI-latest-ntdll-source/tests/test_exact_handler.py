#!/usr/bin/env python3
"""Exercise current c2c1b03a production branch. Extracted code LGPL-2.1+; new harness MIT."""
from pathlib import Path
import hashlib, json, subprocess

ROOT = Path(__file__).resolve().parents[1]
HERE = ROOT / 'build/host'
HERE.mkdir(parents=True, exist_ok=True)
SRC = ROOT / 'proof/current-signal_arm64_ios.c'
EXPECTED = 'e4bddf4e67e5925653f22ff41372ddd4e0fec53a075ff9c9eefe4a7a3ba0879b'
raw = SRC.read_bytes()
assert hashlib.sha256(raw).hexdigest() == EXPECTED
source = raw.decode()
start = source.index('                    else if ((insn & 0x3fe07c00) == 0x08007c00)')
end = source.index('                    /* iOS-Madeira ml626:', start)
branch = source[start:end]
assert branch.count('else if') == 1
assert hashlib.sha256(branch.encode()).hexdigest() == '78dd522bc4986cb61135a340701c6bff13ebeace7c5931b31b2a2b4fc0021eac'
extracted = branch.replace('else if', 'if', 1)
prefix = r'''
#include <assert.h>
#include <pthread.h>
#include <stdint.h>
#include <stdio.h>
#include <string.h>
#include <sys/mman.h>
#include <unistd.h>
struct state { uint64_t __x[29], __fp, __lr, __sp; };
static const uint32_t original[] = {0x885ffd0b,0x0a0a016b,0x880cfd0b,0x35ffffac};
static const uint32_t patched[] = {0x885ffd0c,0x0a0a018b,0x880cfd0b,0x35ffffac};
static int ios_fault_read_insn(uint64_t pc, uint32_t *out) {
    uintptr_t p=(uintptr_t)pc;
    const uint32_t *sets[]={ original,patched };
    for(unsigned i=0;i<2;i++) if(p>=(uintptr_t)sets[i] && p-(uintptr_t)sets[i]<sizeof(original) && !(p&3)) {
        memcpy(out,(const void*)p,4); return 1;
    }
    return 0;
}
#define IOS_STORE_SRC(r) ((r) == 31 ? 0ULL : state.__x[r])
static int route(const uint32_t *code, uintptr_t fault_addr, uintptr_t rw_addr, struct state *st) {
    const uint64_t fault_pc=(uintptr_t)(code+2);
    const uint32_t insn=code[2];
    struct state state=*st;
    int emulated=0;
'''
suffix = r'''
    *st=state;
    return emulated;
}
static uint32_t *rw,*rw2;
static const uint32_t *rx;
static struct state seed(uint32_t old, uint32_t mask, const uint32_t *addr) {
    struct state s={0};
    for(unsigned i=0;i<29;i++) s.__x[i]=0x1234567800000000ull+i;
    s.__x[8]=(uintptr_t)addr; s.__x[10]=mask; s.__x[11]=old&mask; s.__x[12]=old;
    return s;
}
static unsigned completed;
enum { N=4, ROUNDS=10000 };
static void *worker(void *v) {
    unsigned bit=(unsigned)(uintptr_t)v;
    uint32_t mine=1u<<bit;
    for(unsigned j=0;j<ROUNDS;j++) {
        assert(!(__atomic_fetch_or(rw2,mine,__ATOMIC_SEQ_CST)&mine));
        for(;;) {
            uint32_t old=__atomic_load_n(rx,__ATOMIC_ACQUIRE);
            struct state st=seed(old,~mine,rx);
            assert(old&mine);
            assert(route(patched,(uintptr_t)rx,(uintptr_t)rw,&st));
            if(!st.__x[12]) break;
            assert(st.__x[12]==1);
        }
        assert(!(__atomic_load_n(rx,__ATOMIC_SEQ_CST)&mine));
    }
    __atomic_fetch_add(&completed,1,__ATOMIC_SEQ_CST);
    return NULL;
}
int main(void) {
    long page=sysconf(_SC_PAGESIZE);
    FILE *file=tmpfile(); assert(file && !ftruncate(fileno(file),page));
    rw=mmap(NULL,page,PROT_READ|PROT_WRITE,MAP_SHARED,fileno(file),0);
    rx=mmap(NULL,page,PROT_READ,MAP_SHARED,fileno(file),0);
    rw2=mmap(NULL,page,PROT_READ|PROT_WRITE,MAP_SHARED,fileno(file),0);
    assert(rw!=MAP_FAILED && rx!=MAP_FAILED && rw2!=MAP_FAILED);
    struct state st,pre;
    *rw=0x7fffffff;
    st=seed(*rw,0xfffffffe,rx); st.__x[12]=0xabcdef00;
    st.__x[11]=*rw&0xfffffffe; pre=st;
    assert(!route(original,(uintptr_t)rx,(uintptr_t)rw,&st));
    assert(*rw==0x7fffffff && !memcmp(&st,&pre,sizeof st));
    static const uint32_t vals[]={0,1,2,0x7fffffff,0x80000000,0xffffffff,0xdeadbeef};
    static const uint32_t masks[]={0,1,0xfffffffe,0x80000000,0xffffffff,0x55555555};
    unsigned vectors=0;
    for(unsigned a=0;a<sizeof(vals)/4;a++) for(unsigned b=0;b<sizeof(masks)/4;b++) {
        uint32_t old=vals[a],mask=masks[b]; *rw=old;
        st=seed(old,mask,rx); pre=st;
        assert(route(patched,(uintptr_t)rx,(uintptr_t)rw,&st));
        assert(*rw==(old&mask) && *rx==(old&mask) && st.__x[12]==0);
        pre.__x[12]=0; assert(!memcmp(&st,&pre,sizeof st));
        *rw=old^0x100;
        st=seed(old,mask,rx); pre=st;
        assert(route(patched,(uintptr_t)rx,(uintptr_t)rw,&st));
        assert(*rw==(old^0x100) && st.__x[12]==1);
        pre.__x[12]=1; assert(!memcmp(&st,&pre,sizeof st));
        old=*rw; st=seed(old,mask,rx);
        assert(route(patched,(uintptr_t)rx,(uintptr_t)rw,&st));
        assert(!st.__x[12] && *rw==(old&mask));
        vectors++;
    }
    *rw=0;
    pthread_t threads[N];
    for(unsigned i=0;i<N;i++) assert(!pthread_create(&threads[i],NULL,worker,(void*)(uintptr_t)i));
    for(unsigned i=0;i<N;i++) assert(!pthread_join(threads[i],NULL));
    assert(completed==N && *rx==0);
    printf("PASS: exact production branch; original refuses; %u success/race/retry vectors; %u threads x %u atomic set/clear rounds; distinct shared aliases\n",vectors,N,ROUNDS);
    assert(!munmap(rw,page)&&!munmap((void*)rx,page)&&!munmap(rw2,page)); fclose(file);
}
'''
code = prefix + extracted + suffix
(HERE/'test_exact_handler.c').write_text(code)
cmd=['xcrun','clang','-std=c11','-D_DARWIN_C_SOURCE','-O1','-g','-fsanitize=address,undefined','-fno-omit-frame-pointer','-pthread',str(HERE/'test_exact_handler.c'),'-o',str(HERE/'test_exact_handler')]
build=subprocess.run(cmd,text=True,capture_output=True)
(HERE/'test-build.stderr.txt').write_text(build.stderr)
assert build.returncode==0, build.stderr
(HERE/'test_exact_handler').chmod(0o700)
run=subprocess.run([str(HERE/'test_exact_handler')],text=True,capture_output=True)
(HERE/'test-run.stdout.txt').write_text(run.stdout)
(HERE/'test-run.stderr.txt').write_text(run.stderr)
report={'source':str(SRC.relative_to(ROOT)),'source_sha256':EXPECTED,'production_branch_sha256':hashlib.sha256(branch.encode()).hexdigest(),'extraction_change':'Only replace leading else if with if; branch body unmodified','compiler_command':[v.replace(str(ROOT)+'/', '') for v in cmd],'exit_code':run.returncode,'stdout':run.stdout,'limitations':['Host arm64 sanitizer exercise, not iPhone runtime','Value-based CAS recovery already permits ABA and is not a full hardware exclusive-monitor emulation','Does not execute altered ntdll PE or sign/install anything']}
(HERE/'test-results.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report,indent=2))
assert run.returncode==0, run.stderr
