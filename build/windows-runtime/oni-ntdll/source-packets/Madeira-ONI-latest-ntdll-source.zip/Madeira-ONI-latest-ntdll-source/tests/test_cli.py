#!/usr/bin/env python3
"""MIT. Check atomic CLI replacement and refusal without changing original bytes."""
from pathlib import Path
import hashlib,json,os,shutil,stat,subprocess,sys,tempfile
ROOT=Path(__file__).resolve().parents[1]
DATA=(ROOT/'baseline/ntdll.dll').read_bytes()
CANDIDATE='153af52414270ff9a373210c0fcecbfad3f54cffddcc88181ef1ddd2dccb8833'
checks=[]
with tempfile.TemporaryDirectory(prefix='cli-',dir=ROOT/'build') as td:
 d=Path(td)
 def run(args,ok):
  r=subprocess.run([sys.executable,str(ROOT/'patch_ntdll.py'),*map(str,args)],text=True,capture_output=True,env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1'))
  assert (r.returncode==0)==ok,(args,r.stdout,r.stderr)
 def refusal(label,args,watched):
  before={p:(p.read_bytes(),stat.S_IMODE(p.stat().st_mode)) for p in watched}
  run(args,False)
  assert all((p.read_bytes(),stat.S_IMODE(p.stat().st_mode))==v for p,v in before.items()),label
  checks.append(label)
 b=d/'input.dll';b.write_bytes(DATA);b.chmod(0o640)
 out=d/'output.dll';report=d/'report.json'
 run([b,out,'--report',report],True)
 assert hashlib.sha256(out.read_bytes()).hexdigest()==CANDIDATE and stat.S_IMODE(out.stat().st_mode)==0o640
 checks.append('new output full hash and mode')
 refusal('refuse existing output',[b,out,'--report',d/'unused.json'],[b,out])
 refusal('refuse existing report',[b,d/'unused.dll','--report',report],[b,report])
 refusal('refuse same path without flag',[b,b,'--report',d/'same.json'],[b])
 refusal('refuse flag on distinct paths',[b,d/'flag.dll','--in-place','--report',d/'flag.json'],[b])
 refusal('refuse report aliases baseline',[b,d/'alias.dll','--report',b],[b])
 link=d/'symlink.dll';link.symlink_to(b)
 refusal('refuse symbolic baseline',[link,d/'symout.dll','--report',d/'sym.json'],[b])
 hard=d/'hard.dll';os.link(b,hard)
 refusal('refuse multiply linked baseline',[b,b,'--in-place','--report',d/'hard.json'],[b,hard]);hard.unlink()
 bad=d/'bad.dll';mut=bytearray(DATA);mut[0x80]^=1;bad.write_bytes(mut)
 refusal('refuse wrong full hash inplace',[bad,bad,'--in-place','--report',d/'bad.json'],[bad])
 run([b,b,'--in-place','--report',d/'inplace.json'],True)
 assert hashlib.sha256(b.read_bytes()).hexdigest()==CANDIDATE and stat.S_IMODE(b.stat().st_mode)==0o640
 assert not list(d.glob('.oni-ntdll-*'))
 checks.append('atomic same-path full hash/mode and no leaked temporary')
 refusal('refuse already patched input inplace',[b,b,'--in-place','--report',d/'again.json'],[b])
result={'suite':'guarded atomic CLI','pass':True,'checks':len(checks),'cases':checks}
(ROOT/'build/cli-tests.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))
