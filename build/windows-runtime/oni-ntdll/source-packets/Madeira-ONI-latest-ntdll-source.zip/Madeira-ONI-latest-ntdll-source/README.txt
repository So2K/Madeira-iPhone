Latest Madeira ONI allocator-alias compatibility patch; experimental source packet

Scope: exact official c2c1b03a9e36ef986c980b9eae3c14d05a372db1 ARM64EC-header ntdll.
Input SHA256 3aca1fee7b0c03c56771f809bb7dae7caa1d6bb952d9b17592d6336019eaae4f
Output SHA256 153af52414270ff9a373210c0fcecbfad3f54cffddcc88181ef1ddd2dccb8833
Both 1,572,864 bytes. Only file offsets/RVAs 0x28400 (0b -> 0c) and
0x28404 (6b -> 8b) differ. See src/allocator_loop.S for complete changed code.
This changes load destination W11 to W12 and AND input W11 to W12, preserving
STLXR W12,W11,[X8], CBNZ W12 retry, width, ordering and loop live-outs.
It lets the existing current production writable-alias CAS handler retain the
original load value. It does not pretend a failed store succeeded.

Reproduce offline against an independently acquired exact input:
  bash build.sh /path/to/exact/ntdll.dll /new/path/ntdll.dll /new/path/report.json
No input PE or output PE is included in this source archive. The exact input is
in the verified official GitHub artifact named in baseline-provenance.json.
The script refuses other full hashes, sizes, context, export/thunk contracts,
metadata/architecture, incoming interior references, relocations and deltas.

CI interface:
  python3 patch_ntdll.py INPUT OUTPUT --report NEW_JSON
Explicit same-path atomic replacement additionally requires --in-place.
Input must be a regular single-link file. All guards precede mutation; a pinned
candidate is fsynced to a sibling temporary and atomically replaces the original
while preserving its file mode. PE replacement and JSON report are not one atomic transaction; no power-loss durability is claimed. Already patched inputs are deliberately refused.
The report path must not already exist. CI must create/use a fresh report path.

CI hook: end of build/windows-runtime/build.sh before targets.py closure, before
runtime-components.py snapshots Windows runtime hashes. Vendor the reviewed
recipe under build/windows-runtime/oni-ntdll/, which is in windows source-key
inputs. Do not patch after the component manifest or before a later ntdll rebuild.
See ci-integration.json for exact upstream source pins and the open reproducibility
risk: current build scripts have no visible timestamp normalization; the pinned
linker probe emits different timestamps. A new complete Wine rebuild MAY fail
the exact input hash. Fail closed; do not normalize/ignore bytes or widen pins
without separate review. This packet does not assert that a clean full CI build
reproduces the official input. Such a build has not been run here.

Tests (Apple arm64 host, xcrun clang, ASAN+UBSan): place exact input at
baseline/ntdll.dll, then run bash test.sh and python3 tests/test_cli.py.
33 strict transform checks, 11 CLI checks; actual current c2 native CAS branch
42 success/race/retry vectors plus 4x10,000 operations across shared aliases;
real ARM64 old/new instruction loops 30 equivalent live-out vectors plus
4x20,000 mixed-loop contended operations. Assembly was separately reassembled
with pinned llvm-mingw clang22.1.4, target aarch64-none-elf, producing exact32 bytes.
Frozen source/proofs/reports are included. Independent fresh CFG analysis scans
all advertised native ranges, full CHPE maps/exports/unwind entries; its unchanged
review.py retains the original workspace path and is evidence, not the build CLI.

Limits: host tests and static analysis do not establish iPhone launch, game
correctness, frame rate or full hardware-exclusive/ABA semantics. Current alias
handler uses value-based compare-exchange; its existing ABA limitation remains.
No native GPR changes, signing, profiles, accounts, app staging or device access
are performed by this packet. Native GPR fix is separately reviewed/integrated.

Licenses: changed Wine assembly/proof Wine sources LGPL-2.1-or-later. Madeira
signal source retains its headers, GPL-3.0 and additional exception notices.
New utility/tests/docs MIT. See licenses/ and source-provenance.json.
