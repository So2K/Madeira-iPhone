#!/usr/bin/env python3
"""Independent read-only review of the latest official ntdll; no PE output."""
from pathlib import Path
import hashlib,json,struct,re
HERE=Path(__file__).resolve().parent
ROOT=HERE.parent.parent
INPUT=ROOT/'work/oxygen-latest-ntdll-plan/baseline/ntdll.dll'
EXPECTED='3aca1fee7b0c03c56771f809bb7dae7caa1d6bb952d9b17592d6336019eaae4f'
b=INPUT.read_bytes()
def sha(x): return hashlib.sha256(x).hexdigest()
def unpack(fmt,off):
 n=struct.calcsize(fmt);assert 0<=off<=len(b)-n
 return struct.unpack_from(fmt,b,off)
def sx(v,n):return v-(1<<n) if v&(1<<(n-1)) else v
assert sha(b)==EXPECTED and len(b)==1572864
assert b[:2]==b'MZ'
pe=unpack('<I',60)[0];assert b[pe:pe+4]==b'PE\0\0'
machine,nsec,timestamp,sym,nsyms,optsize,flags=unpack('<HHIIIHH',pe+4)
opt=pe+24;assert unpack('<H',opt)[0]==0x20b and optsize==240
base=unpack('<Q',opt+24)[0]
image_size,header_size=unpack('<II',opt+56)
ndirs=unpack('<I',opt+108)[0];assert ndirs==16
assert machine==0x8664 and nsec==8 and flags==0x2022 and base==0x180000000
sections=[]
for i in range(nsec):
 p=opt+optsize+i*40
 name=b[p:p+8].split(b'\0')[0].decode('ascii')
 vs,va,rs,raw=unpack('<IIII',p+8);ch=unpack('<I',p+36)[0]
 assert raw+rs<=len(b) and va+max(vs,rs)<=image_size
 sections.append({'name':name,'virtual_size':vs,'rva':va,'raw_size':rs,'file_offset':raw,'characteristics':ch,'raw_sha256':sha(b[raw:raw+rs])})
def at(rva,n):
 assert 0<=rva<=image_size-n
 if rva<header_size:
  assert rva+n<=min(header_size,len(b));return rva
 ss=[s for s in sections if s['rva']<=rva and rva+n<=s['rva']+s['raw_size']]
 assert len(ss)==1,(hex(rva),n)
 return ss[0]['file_offset']+rva-ss[0]['rva']
def get(fmt,rva):return unpack(fmt,at(rva,struct.calcsize(fmt)))
def cstr(rva):
 off=at(rva,1);end=b.find(b'\0',off,min(len(b),off+4096));assert end>=off
 at(rva,end-off+1);return b[off:end].decode('ascii')
def span(rva,n):return b[at(rva,n):at(rva,n)+n]
dirs=[unpack('<II',opt+112+8*i) for i in range(16)]
dirnames=['exports','imports','resources','exception','certificate','relocations','debug','architecture','globalptr','tls','load_config','bound_import','iat','delay_import','clr','reserved']
directory_report=[{'name':name,'rva':r,'size':n,'sha256':sha(span(r,n)) if r and n else None} for name,(r,n) in zip(dirnames,dirs)]
assert dirs[1]==dirs[11]==dirs[12]==dirs[13]==(0,0)
# Full export address/name/ordinal/forwarder contract, not only export names.
er,esz=dirs[0]
eflags,etime,emaj,emin,dllname,obase,nfunc,nnames,fr,nr,orr=get('<IIHH7I',er)
assert 0<nfunc<=65536 and nnames<=nfunc
funcs=get('<'+'I'*nfunc,fr);names=get('<'+'I'*nnames,nr);ords=get('<'+'H'*nnames,orr)
byindex={}
for nrva,idx in zip(names,ords):
 assert idx<nfunc;byindex.setdefault(idx,[]).append(cstr(nrva))
exports=[]
for i,r in enumerate(funcs):
 if not r:continue
 fwd=cstr(r) if er<=r<er+esz else None
 if not fwd:at(r,1)
 exports.append({'ordinal':obase+i,'names':byindex.get(i,[]),'rva':r,'forwarder':fwd})
assert len(set(n for e in exports for n in e['names']))==nnames
rtl=[e for e in exports if 'RtlAllocateHeap' in e['names']];assert len(rtl)==1
# Current v2 ARM64EC metadata. Stable first 20 DWORDs plus explicit v2 tail.
lcr,lcs=dirs[10];lc=span(lcr,lcs);assert lcs==320 and struct.unpack_from('<I',lc)[0]==320
chpeva=struct.unpack_from('<Q',lc,200)[0];assert base<chpeva<base+image_size
cr=chpeva-base
fields=get('<29I',cr)
assert fields[0]==2
cm,cmn,entryr,redir=fields[1:5];entryn,redn=fields[12:14];rfer,rfesz=fields[16:18]
assert 0<cmn<=256 and 0<entryn<=10000 and redn<=10000 and rfesz%8==0
ranges=[]
for i in range(cmn):
 raw,n=get('<II',cm+8*i);start=raw&~3;kind=raw&3
 assert kind in (0,1,2) and n and start+n<=image_size
 at(start,1);at(start+n-1,1)
 ranges.append({'start':start,'end_exclusive':start+n,'kind':kind,'type':{0:'ARM64',1:'ARM64EC',2:'X64'}[kind]})
entries=[get('<III',entryr+12*i) for i in range(entryn)]
redirections=[get('<II',redir+8*i) for i in range(redn)]
rfes=[get('<II',rfer+8*i) for i in range(rfesz//8)]
assert ranges==[{'start':0x10000,'end_exclusive':0x85a6c,'kind':1,'type':'ARM64EC'},{'start':0x86000,'end_exclusive':0x93ae0,'kind':2,'type':'X64'}]
assert all(rfes[i][0]<rfes[i+1][0] for i in range(len(rfes)-1))
loop,end=0x28400,0x28410
assert at(loop,16)==loop
old=get('<4I',loop);assert old==(0x885ffd0b,0x0a0a016b,0x880cfd0b,0x35ffffac)
new=(0x885ffd0c,0x0a0a018b,old[2],old[3])
# Decode every aligned instruction in every current native range.
branches=[];adrs=[];adrps=[];indirects=0;instructions=0
for rg in ranges:
 if rg['kind']==2:continue
 assert rg['start']%4==rg['end_exclusive']%4==0
 for rva in range(rg['start'],rg['end_exclusive'],4):
  ins=get('<I',rva)[0];instructions+=1;dest=None;kind=None
  if ins&0x7c000000==0x14000000:dest=rva+(sx(ins&0x3ffffff,26)<<2);kind='BL' if ins&0x80000000 else 'B'
  elif ins&0xff000010==0x54000000:dest=rva+(sx((ins>>5)&0x7ffff,19)<<2);kind='B.cond'
  elif ins&0x7e000000==0x34000000:dest=rva+(sx((ins>>5)&0x7ffff,19)<<2);kind='CBNZ' if ins&(1<<24) else 'CBZ'
  elif ins&0x7e000000==0x36000000:dest=rva+(sx((ins>>5)&0x3fff,14)<<2);kind='TBNZ' if ins&(1<<24) else 'TBZ'
  if dest is not None and loop<=dest<end:branches.append({'from_rva':rva,'target_rva':dest,'kind':kind,'opcode':ins})
  if ins&0x9f000000==0x10000000:
   dest=rva+sx((((ins>>5)&0x7ffff)<<2)|((ins>>29)&3),21)
   if loop<=dest<end:adrs.append({'from_rva':rva,'target_rva':dest,'opcode':ins})
  if ins&0x9f000000==0x90000000:
   dest=(rva&~0xfff)+(sx((((ins>>5)&0x7ffff)<<2)|((ins>>29)&3),21)<<12)
   if dest==loop&~0xfff:adrps.append({'from_rva':rva,'target_page_rva':dest,'opcode':ins})
  if ins&0xfe000000==0xd6000000:indirects+=1
assert branches==[{'from_rva':0x2840c,'target_rva':0x28400,'kind':'CBNZ','opcode':0x35ffffac}]
assert not adrs
# Resolve the two current ADRP + ADD materializations of this native page.
for ref in adrps:
 ins=get('<I',ref['from_rva'])[0];add=get('<I',ref['from_rva']+4)[0]
 rd=ins&31
 assert add&0xffc00000==0x91000000 and add&31==rd and add>>5&31==rd
 imm=(add>>10)&0xfff
 ref['following_ADD_opcode']=add
 ref['resolved_materialized_rva']=ref['target_page_rva']+imm
 ref['resolved_target_in_loop']=loop<=ref['resolved_materialized_rva']<end
 assert not ref['resolved_target_in_loop']
assert [x['resolved_materialized_rva'] for x in adrps]==[0x281ac,0x28080]
entryhits=[{'start':s,'end':e,'entry':ep} for s,e,ep in entries if loop<=ep<end or loop<=s<end or loop<e<=end]
redirhits=[{'source':s,'destination':d} for s,d in redirections if loop<=s<end or loop<=d<end]
exporthits=[e for e in exports if loop<=e['rva']<end]
rfehits=[{'start':s,'unwind':u} for s,u in rfes if loop<=s<end]
assert not entryhits and not redirhits and not exporthits and not rfehits
owner=max((r for r in rfes if r[0]<=loop),key=lambda r:r[0]);nextowner=min(r[0] for r in rfes if r[0]>loop)
assert owner[1]&3==0
uw=get('<I',owner[1])[0];ownerend=owner[0]+(uw&0x3ffff)*4
assert owner[0]==0x281ac and ownerend==0x28acc and ownerend<=nextowner
assert rtl[0]['rva']==0x90970 and (rtl[0]['rva'],owner[0]) in redirections
# Verify AMD64 export stub's final E9 rel32 target independently.
off=at(rtl[0]['rva'],16);stub=b[off:off+16];assert stub[9]==0xe9
stubtarget=rtl[0]['rva']+14+struct.unpack_from('<i',stub,10)[0]
assert stubtarget==owner[0]
# No modified byte belongs to a non-.text metadata range or any directory.
patch=[{'file_offset':loop,'before':11,'after':12},{'file_offset':loop+4,'before':107,'after':139}]
assert all(not (r<=p['file_offset']<r+n) for r,n in dirs for p in patch if r and n)
# In-memory instruction decoding only: never create or hash a hypothetical candidate.
decoded_new={'load_destination_w':new[0]&31,'load_base_x':new[0]>>5&31,'and_destination_w':new[1]&31,'and_lhs_w':new[1]>>5&31,'and_rhs_w':new[1]>>16&31,'store_value_w':new[2]&31,'store_base_x':new[2]>>5&31,'store_status_w':new[2]>>16&31,'retry_condition_w':new[3]&31,'retry_target':loop+12+(sx(new[3]>>5&0x7ffff,19)<<2)}
assert decoded_new=={'load_destination_w':12,'load_base_x':8,'and_destination_w':11,'and_lhs_w':12,'and_rhs_w':10,'store_value_w':11,'store_base_x':8,'store_status_w':12,'retry_condition_w':12,'retry_target':loop}
assert get('<4I',end)==(0x9b097cec,0xd5033bbf,0xb9401349,0xf9402beb)
report={
 'schema':1,'verdict':'GO for exact two-byte latest-PE register-allocation change, subject to separate current native-handler and device canary review',
 'input':{'path':str(INPUT.relative_to(ROOT)),'bytes':len(b),'sha256':sha(b),'read_only':True},
 'tool_note':'llvm-readobj reports normalized IMAGE_FILE_MACHINE_ARM64EC 0xA641; actual on-disk COFF machine is AMD64 0x8664, independently parsed from PE+4. Its --unwind output warns .pdata content is not 8-byte aligned because the section combines native and AMD64 tables; native ExtraRFETable is separately mapped and exactly 8-byte aligned.',
 'pe':{'raw_coff_machine':machine,'timestamp':timestamp,'flags':flags,'image_base':base,'image_size':image_size,'header_size':header_size,'number_of_sections':nsec,'optional_header_size':optsize,'entrypoint_rva':unpack('<I',opt+16)[0],'sections':sections,'directories':directory_report,'imports':[],'delay_imports':[],'exports_count':len(exports),'export_function_slots':nfunc,'export_names_count':nnames,'export_dll_name':cstr(dllname),'exports_canonical_sha256':sha(json.dumps(exports,sort_keys=True,separators=(',',':')).encode())},
 'chpe':{'version':2,'metadata_rva':cr,'first_116_bytes_sha256':sha(span(cr,116)),'code_ranges':ranges,'code_map_raw_sha256':sha(span(cm,8*cmn)),'code_ranges_to_entrypoints_rva':entryr,'code_ranges_to_entrypoints_count':entryn,'code_ranges_to_entrypoints_sha256':sha(span(entryr,12*entryn)),'redirections_rva':redir,'redirections_count':redn,'redirections_sha256':sha(span(redir,8*redn)),'extra_rfe_rva':rfer,'extra_rfe_bytes':rfesz,'extra_rfe_count':len(rfes),'extra_rfe_sha256':sha(span(rfer,rfesz)),'load_config_sha256':sha(lc),'fields_dword':list(fields)},
 'owner':{'export':rtl[0],'export_stub_bytes':stub.hex(),'export_jump_target':stubtarget,'native_start':owner[0],'native_end_exclusive':ownerend,'native_unwind_rva':owner[1],'native_unwind_header':uw,'next_native_start':nextowner},
 'loop':{'start_rva':loop,'end_exclusive':end,'file_offset':at(loop,16),'original_words':old,'intended_words':new,'intended_exact_byte_delta':patch,'decoded_intended':decoded_new},
 'cfg':{'native_aligned_instructions_scanned':instructions,'native_scan_ranges':[r for r in ranges if r['kind']!=2],'direct_branch_references_to_loop':branches,'interior_branch_references':[],'direct_ADR_references_to_loop':adrs,'ADRP_references_to_loop_page':adrps,'CHPE_entrypoint_hits':entryhits,'CHPE_redirection_hits':redirhits,'PE_export_hits':exporthits,'native_unwind_start_hits':rfehits,'indirect_branch_encoding_count':indirects},
 'liveness':{
  'W11':'Original LDAXR writes W11, AND writes W11 from loaded value. Intended LDAXR writes W12, AND still writes W11 from the same loaded value and W10 mask. Thus W11 desired store value is equal at STLXR, retry edge, and successful loop exit. X11 is reloaded from [SP+0x50] at 0x2841C before subsequent use.',
  'W12':'STLXR status writes W12 in both variants before CBNZ. On failure both have W12=nonzero and retry reloads a fresh old value; on success both have W12=0. No other instruction observes the newly changed W12 between LDAXR and STLXR. At 0x28410 MUL X12,X7,X9 unconditionally overwrites X12; incoming X12 does not escape the loop.',
  'NZCV':'LDAXR, non-S AND, STLXR and CBNZ do not modify NZCV. Neither changed encoding uses ANDS, flag-setting arithmetic or B.cond; entry flags are retained exactly on both retry and exit.',
  'remaining_state':'X8 memory address, W10 mask, memory width, acquire/release ordering, STLXR store operand W11/status W12, retry target, stack/frame and all other register operands are unchanged. No changed instruction adds control flow, stack access or unwind obligations.',
  'alias_handler_requirement':'The intended allocation leaves the original load value in W12 at the STLXR fault, while W11 contains the desired value. Whether the current native iPhone alias handler recognizes and uses this state is outside this PE-only review; do not inherit an older native handler proof.'},
 'limits':['A complete scan of current advertised native ranges proves no encoded direct branch into the three interior loop instructions. It cannot exclude arbitrary runtime-computed jumps, corruption or dynamically rewritten code.','The two ADRP references to the loop page are followed by ADD and resolve to function starts 0x281AC and 0x28080, outside the loop. Static analysis cannot prove what arbitrary future code does with computed addresses.','No baseline-to-candidate comparison was performed: this review did not create, patch or receive a candidate. A separate exact-delta guard must verify all file bytes and metadata unchanged except the two specified bytes.','Static equivalence applies to ordinary ARM64 execution; host/device tests and current alias-handler semantics remain separate requirements.','No signing, source patch, staging, credentials, app or device access.']}
(HERE/'exports.json').write_text(json.dumps(exports,indent=2)+'\n')
(HERE/'review.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({'verdict':report['verdict'],'input':report['input'],'pe':{k:report['pe'][k] for k in ['raw_coff_machine','exports_count','export_function_slots','export_names_count']},'chpe':{k:report['chpe'][k] for k in ['version','code_ranges','code_ranges_to_entrypoints_count','redirections_count','extra_rfe_count']},'owner':report['owner'],'cfg':report['cfg']},indent=2))
