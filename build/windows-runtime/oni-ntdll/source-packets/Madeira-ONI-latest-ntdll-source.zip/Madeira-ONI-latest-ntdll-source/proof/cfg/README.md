# Fresh latest-official ntdll review

Verdict: **GO for the exact two-byte PE register-allocation change**, contingent on a separate review of the current native alias handler and a device canary. This review does not sign, stage, install, produce a candidate or claim game success.

Input: `work/oxygen-latest-ntdll-plan/baseline/ntdll.dll`, 1,572,864 bytes, SHA256 `3aca1fee7b0c03c56771f809bb7dae7caa1d6bb952d9b17592d6336019eaae4f`.

The actual COFF machine is `0x8664`; LLVM presents the image as ARM64EC `0xA641`. Raw PE and independent LLVM metadata checks agree on eight sections, 1,473 named exports, no imports or delay imports, and CHPE **version 2**. The current native range is `[0x10000, 0x85A6C)`; x64 range `[0x86000, 0x93AE0)`. Both entry-point and redirection tables contain 1,201 records. The ExtraRFETable at RVA `0xF0000` has 1,915 native unwind records. These values were freshly parsed; old metadata was not assumed.

All **120,475** aligned native instructions were scanned for B/BL, B.cond, CBZ/CBNZ, TBZ/TBNZ and direct ADR references. The only direct branch into `[0x28400, 0x28410)` is the existing retry at `0x2840C → 0x28400`. No encoded direct branch, export, CHPE entry/redirection or native unwind start enters the three interior instructions. Two ADRP references to page `0x28000` resolve through their immediate ADD to `0x281AC` and `0x28080`, outside the loop. Computed jumps cannot be excluded by static analysis.

`RtlAllocateHeap`, ordinal 414, exports the x64 stub RVA `0x90970`; both its actual E9 displacement and current CHPE redirection resolve to native `0x281AC`. Native unwind covers `[0x281AC, 0x28ACC)` with unwind RVA `0xC963C`.

The intended bytes are file/RVA `0x28400: 0B → 0C` and `0x28404: 6B → 8B`:

```asm
LDAXR W12, [X8]
AND   W11, W12, W10
STLXR W12, W11, [X8]  ; unchanged
CBNZ  W12, 0x28400    ; unchanged
```

W11 has the same desired value at the store, retry edge and successful exit. STLXR overwrites W12 with the same status in both variants; after success W12 is zero. The next instruction at `0x28410` overwrites X12 with `MUL X12,X7,X9`, and `0x2841C` reloads X11 before later use. Neither original nor intended loop modifies NZCV. Memory width, address, mask, acquire/release ordering, branch, frame and unwind behavior are unchanged. At a faulting STLXR the intended allocation additionally preserves the original loaded value in W12; compatibility with the **current** native handler must be independently established.

Reproduce with `python3 work/oxygen-latest-ntdll-cfg-review/review.py`. Detailed metadata, all export ordinals/names/RVAs/forwarders, code context, report and file hashes are adjacent. The LLVM `.pdata content is not 8-byte aligned` warning refers to the combined section; the separately mapped native ExtraRFETable is exactly divisible by eight and all 1,915 records were parsed.
