#!/bin/bash
# MIT. Offline patch reproduction, not a full Wine or native-iOS build.
set -euo pipefail
TASK_ROOT="$(cd "$(dirname "$0")" && pwd)"
if [[ $# -lt 2 || $# -gt 3 ]]; then
  echo "usage: bash build.sh EXACT_BASELINE_NTDLL NEW_OUTPUT_NTDLL [NEW_REPORT_JSON]" >&2
  exit 2
fi
python3 "$TASK_ROOT/patch_ntdll.py" "$1" "$2" --report "${3:-$2.verification.json}"
