#!/usr/bin/env python3
"""MIT. Deterministic source-only packet, binaries excluded."""
from pathlib import Path
import hashlib,json,zipfile
ROOT=Path(__file__).resolve().parent
PREFIX='Madeira-ONI-latest-ntdll-source/'
ZIP=ROOT/'Madeira-ONI-latest-ntdll-source.zip'
check=lambda ok,msg: None if ok else (_ for _ in ()).throw(RuntimeError(msg))
check(not ZIP.exists(),'Refuse archive overwrite')
files=[]
for f in ROOT.rglob('*'):
 if not f.is_file():continue
 rel=f.relative_to(ROOT).as_posix()
 if rel.startswith(('baseline/','build/')):
  if rel not in ['build/verification.json','build/guard-tests.json','build/cli-tests.json','build/assembly-verification.json','build/native-loop-results.txt','build/host/test-results.json','build/host/test-run.stdout.txt','build/host/test-run.stderr.txt','build/host/test-build.stderr.txt','build/timestamp-probe.json']:continue
 if rel.endswith(('.pyc','.zip')) or rel in ['release-manifest.json']:continue
 files.append((rel,f))
records={}
with zipfile.ZipFile(ZIP,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for rel,f in sorted(files):
  raw=f.read_bytes();i=zipfile.ZipInfo(PREFIX+rel,(2020,1,1,0,0,0));i.create_system=3;i.external_attr=0o100600<<16;i.compress_type=zipfile.ZIP_DEFLATED;z.writestr(i,raw)
  records[PREFIX+rel]={'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest(),'mode':0o100600}
with zipfile.ZipFile(ZIP) as z:
 check(z.testzip() is None,'Archive CRC failure');check(set(z.namelist())==set(records),'Member map')
 for name,record in records.items():check(hashlib.sha256(z.read(name)).hexdigest()==record['sha256'],'Member bytes')
manifest={'schema':1,'source_zip':ZIP.name,'source_zip_sha256':hashlib.sha256(ZIP.read_bytes()).hexdigest(),'source_zip_bytes':ZIP.stat().st_size,'prefix':PREFIX,'member_count':len(records),'members':records,'replacement_pe_sha256':'153af52414270ff9a373210c0fcecbfad3f54cffddcc88181ef1ddd2dccb8833','replacement_pe_bytes':1572864,'baseline_pe_sha256':'3aca1fee7b0c03c56771f809bb7dae7caa1d6bb952d9b17592d6336019eaae4f','strict_recipe_sha256':hashlib.sha256((ROOT/'patch_ntdll.py').read_bytes()).hexdigest(),'build_verification_sha256':hashlib.sha256((ROOT/'build/verification.json').read_bytes()).hexdigest(),'current_handler_source_sha256':'e4bddf4e67e5925653f22ff41372ddd4e0fec53a075ff9c9eefe4a7a3ba0879b','native_CAS_branch_sha256':'78dd522bc4986cb61135a340701c6bff13ebeace7c5931b31b2a2b4fc0021eac','device_acceptance_pending':True}
(ROOT/'release-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(json.dumps({k:manifest[k] for k in ['source_zip_sha256','source_zip_bytes','prefix','member_count','strict_recipe_sha256','build_verification_sha256']},indent=2))
