#!/bin/bash
set -euo pipefail
TASK_ROOT="$(cd "$(dirname "$0")" && pwd)"
python3 - "$TASK_ROOT" <<'PY'
import shutil,sys
assert shutil.disk_usage(sys.argv[1]).free>=576*1024*1024,'Scratch floor576MiB'
PY
python3 "$TASK_ROOT/tests/test_guards.py" > "$TASK_ROOT/build/guard-tests.json"
python3 "$TASK_ROOT/tests/test_cli.py" > "$TASK_ROOT/build/cli-tests.stdout.txt"
python3 "$TASK_ROOT/tests/test_exact_handler.py" > "$TASK_ROOT/build/handler-tests.stdout.txt"
mkdir -p "$TASK_ROOT/build/host"
xcrun clang -O1 -g -fsanitize=address,undefined -fno-omit-frame-pointer -pthread \
  "$TASK_ROOT/tests/test_native_loop.c" "$TASK_ROOT/tests/native-loop.S" \
  -o "$TASK_ROOT/build/host/test_native_loop"
chmod u+x "$TASK_ROOT/build/host/test_native_loop"
"$TASK_ROOT/build/host/test_native_loop" > "$TASK_ROOT/build/native-loop-results.txt"
python3 - "$TASK_ROOT" <<'PY'
import json,sys
from pathlib import Path
p=Path(sys.argv[1]);g=json.loads((p/'build/guard-tests.json').read_text());h=json.loads((p/'build/host/test-results.json').read_text())
assert g['pass'] and h['exit_code']==0
print('PASS: strict negative guards, exact production alias CAS sanitizer suite, and real ARM64 loop equivalence/contention suite')
PY
