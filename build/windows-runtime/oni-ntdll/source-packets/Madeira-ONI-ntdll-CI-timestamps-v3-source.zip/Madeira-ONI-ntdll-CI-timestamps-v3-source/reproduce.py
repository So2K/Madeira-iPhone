#!/usr/bin/env python3
"""MIT. Offline host reconstruction; production CI must use provenance-gated CLI."""
from pathlib import Path
import argparse,importlib.util,json,sys
sys.dont_write_bytecode=True
ROOT=Path(__file__).resolve().parent
ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('baseline',type=Path);ap.add_argument('output',type=Path);ap.add_argument('--report',required=True,type=Path);a=ap.parse_args()
assert not a.output.exists() and not a.report.exists(),'Refuse overwrite'
spec=importlib.util.spec_from_file_location('ci',ROOT/'patch_ntdll_ci.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
out,report=m.transform(a.baseline.read_bytes());report['reconstruction_scope']='Offline host proof only; actual production CLI additionally requires live provenance'
a.output.write_bytes(out);a.report.write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(m.verify_candidate(out),indent=2))
