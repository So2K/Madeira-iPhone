#!/usr/bin/env python3
"""MIT. Source-only reproducible archive; reports contain raw/normalized identities."""
from pathlib import Path
import hashlib,json,zipfile
ROOT=Path(__file__).resolve().parent
PREFIX='Madeira-ONI-ntdll-CI-timestamps-v3-source/'
ZIP=ROOT/'Madeira-ONI-ntdll-CI-timestamps-v3-source.zip'
assert not ZIP.exists(),'Refuse overwrite'
selected=[]
for f in ROOT.rglob('*'):
 if not f.is_file():continue
 rel=f.relative_to(ROOT).as_posix()
 if rel.startswith('build/') and rel not in ['build/timestamp-tests.json','build/provenance-tests.json','build/extra-metadata-tests.json','build/verification.json']:continue
 if rel.endswith(('.pyc','.zip')) or rel in ['release-manifest.json']:continue
 selected.append((rel,f))
records={}
with zipfile.ZipFile(ZIP,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for rel,f in sorted(selected):
  raw=f.read_bytes();i=zipfile.ZipInfo(PREFIX+rel,(2020,1,1,0,0,0));i.create_system=3;i.external_attr=0o100600<<16;i.compress_type=zipfile.ZIP_DEFLATED;z.writestr(i,raw)
  records[PREFIX+rel]={'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest(),'mode':0o100600}
with zipfile.ZipFile(ZIP) as z:
 assert z.testzip() is None and set(z.namelist())==set(records)
 for name,record in records.items():assert hashlib.sha256(z.read(name)).hexdigest()==record['sha256']
manifest={'schema':3,'mode':'pe-build-timestamps-v3','source_zip':ZIP.name,'source_zip_sha256':hashlib.sha256(ZIP.read_bytes()).hexdigest(),'source_zip_bytes':ZIP.stat().st_size,'prefix':PREFIX,'member_count':len(records),'members':records,'runtime_members_sha256':hashlib.sha256((ROOT/'runtime-members.json').read_bytes()).hexdigest(),'verification_sha256':hashlib.sha256((ROOT/'build/verification.json').read_bytes()).hexdigest(),'normalized_input_sha256':'3aca1fee7b0c03c56771f809bb7dae7caa1d6bb952d9b17592d6336019eaae4f','normalized_output_sha256':'153af52414270ff9a373210c0fcecbfad3f54cffddcc88181ef1ddd2dccb8833','allowed_variance_file_offsets':[128,129,130,131,762612,762613,762614,762615],'raw_timestamps_must_equal':True,'raw_timestamps_retained':True,'raw_patch_changed_offsets':[164864,164868],'full_clean_Wine_CI_build_pending':True,'device_acceptance_pending':True}
(ROOT/'release-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(json.dumps({k:manifest[k] for k in ['source_zip_sha256','source_zip_bytes','prefix','member_count','runtime_members_sha256','verification_sha256']},indent=2))
