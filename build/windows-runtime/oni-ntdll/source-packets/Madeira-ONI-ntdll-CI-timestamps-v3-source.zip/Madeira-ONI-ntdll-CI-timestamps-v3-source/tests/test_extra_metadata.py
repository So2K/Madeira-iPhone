#!/usr/bin/env python3
"""MIT. Explicit non-allowed export timestamp and CodeView/GUID refusals."""
from pathlib import Path
import importlib.util,json,struct,sys
sys.dont_write_bytecode=True
ROOT=Path(__file__).resolve().parents[1]
spec=importlib.util.spec_from_file_location('ci',ROOT/'patch_ntdll_ci.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
b=Path(sys.argv[1]).read_bytes();p=m.strict.PE(b);export_ts=p.at(p.dirs[0][0],40)+4
cases={}
for label,off in [('export timestamp outside allowance',export_ts),('CodeView payload/GUID outside allowance',0xBA310),('file padding outside allowance',len(b)-1)]:
 raw=bytearray(b)
 for ts in [0x80,0xBA2F4]:struct.pack_into('<I',raw,ts,17)
 raw[off]^=1
 try:m.transform(bytes(raw))
 except (m.GuardError,m.strict.GuardError):cases[label]={'offset':off,'refused':True}
 else:raise AssertionError(label)
report={'schema':3,'mode':'pe-build-timestamps-v3','pass':True,'checks':len(cases),'cases':cases}
(ROOT/'build/extra-metadata-tests.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
