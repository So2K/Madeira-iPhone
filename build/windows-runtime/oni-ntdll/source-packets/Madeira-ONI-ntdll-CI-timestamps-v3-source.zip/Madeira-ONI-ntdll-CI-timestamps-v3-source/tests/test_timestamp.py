#!/usr/bin/env python3
"""MIT. Two-timestamp full-file guards, pinned compiler fixture, live tool hashes."""
from pathlib import Path
import hashlib,importlib.util,json,os,shutil,struct,subprocess,sys,tempfile,time
sys.dont_write_bytecode=True
ROOT=Path(__file__).resolve().parents[1]
spec=importlib.util.spec_from_file_location('ci',ROOT/'patch_ntdll_ci.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
BASE=Path(sys.argv[1]);TC=Path(sys.argv[2]).resolve();b=BASE.read_bytes();checks=[]
def reject(label,data):
 before=bytes(data)
 try:m.transform(bytes(data))
 except (m.GuardError,m.strict.GuardError,ValueError,struct.error,KeyError):pass
 else:raise AssertionError('accepted mutation '+label)
 assert before==bytes(data);checks.append(label)
for timestamp in [0,1,0x100,0x10000,0x1000000,1793239674,1793239675,0x7fffffff,0xffffffff]:
 raw=bytearray(b);struct.pack_into('<I',raw,0x80,timestamp);struct.pack_into('<I',raw,0xBA2F4,timestamp);raw=bytes(raw)
 out,r=m.transform(raw)
 assert out[0x80:0x84]==raw[0x80:0x84] and out[0xBA2F4:0xBA2F8]==raw[0xBA2F4:0xBA2F8] and m.sha(m.normalize_timestamp(out))==m.PINS['official_candidate_sha256']
 assert [i for i,(x,y) in enumerate(zip(raw,out)) if x!=y]==[0x28400,0x28404]
 assert m.verify_candidate(out)['raw_output_sha256']==m.sha(out)
 checks.append('allowed timestamp '+hex(timestamp))
reject('already patched input',out)
for off in [0x80,0x81,0x82,0x83,0xBA2F4,0xBA2F5,0xBA2F6,0xBA2F7]:
 raw=bytearray(b);raw[off]^=1;reject('isolated mismatched timestamp '+hex(off),raw)
reject('truncated',b[:-1]);reject('appended',b+b'\0')
# Every non-timestamp byte is covered by the single whole-file SHA, including
# padding. The following exercise headers, every section, each loop word and
# unrelated data while also changing the otherwise permitted timestamp.
p=m.strict.PE(b)
mutations={'MZ':0,'PEoffset':0x3c,'PEsignature':p.pe,'machine':p.pe+4,'sections':p.pe+6,'optionalSize':p.pe+20,'flags':p.pe+22,'optionalMagic':p.opt,'entrypoint':p.opt+16,'imageBase':p.opt+24,'imageSize':p.opt+56,'headerSize':p.opt+60,'directoryCount':p.opt+108,'exportDirectory':p.opt+112,'resourceDirectory':p.opt+112+16,'loadConfigDirectory':p.opt+112+80,'ownerExportThunk':0x90970,'loadOpcode':0x28400,'ANDopcode':0x28404,'storeOpcode':0x28408,'retryOpcode':0x2840c,'neighbor':0x283d0,'lastFilePadding':len(b)-1,'debugCharacteristics':0xBA2F0,'debugMajor':0xBA2F8,'debugMinor':0xBA2FA,'debugType':0xBA2FC,'debugSize':0xBA300,'debugPayloadRVA':0xBA304,'debugPayloadFile':0xBA308,'CodeViewGUID':0xBA310,'CodeViewAge':0xBA320,'CodeViewPath':0xBA324}
for s in p.sections:
 mutations['sectionHeader-'+s['name']]=p.opt+240+40*p.sections.index(s)
 if s['raw_bytes']:mutations['sectionBody-'+s['name']]=s['raw_offset']+min(s['raw_bytes']-1,16)
for label,off in mutations.items():
 raw=bytearray(b);struct.pack_into('<I',raw,0x80,17);struct.pack_into('<I',raw,0xBA2F4,17);raw[off]^=1;reject(label,raw)
# Malformed PE/header still cannot be normalized into an accepted object.
for label,data in [('empty',b''),('huge',b'\0'*(4*1024*1024+1)),('invalid-pe-offset',b[:60]+b'\xff'*4+b[64:])]:
 try:m.normalize_timestamp(data)
 except (m.GuardError,m.strict.GuardError,ValueError,struct.error):checks.append('normalizer refuses '+label)
 else:raise AssertionError(label)
toolchain=m.validate_toolchain(TC);checks.append('live9toolchain file hashes')
fixture=[]
with tempfile.TemporaryDirectory(prefix='timestamp-',dir=ROOT/'build') as td:
 d=Path(td);src=d/'fixture.c';target=d/'fixture.dll';src.write_text('int oni_timestamp_fixture(void) { return 7; }\n')
 cmd=[str(TC/'bin/arm64ec-w64-mingw32-clang'),'-shared','-Wl,--exclude-all-symbols',str(src),'-o',str(target)]
 for n in range(2):
  r=subprocess.run(cmd,capture_output=True,text=True);assert r.returncode==0,r.stderr
  strip=subprocess.run([str(TC/'bin/arm64ec-w64-mingw32-strip'),str(target)],capture_output=True,text=True);assert strip.returncode==0,strip.stderr
  raw=target.read_bytes();pe=struct.unpack_from('<I',raw,60)[0]
  fixture.append({'raw_sha256':m.sha(raw),'timestamp':struct.unpack_from('<I',raw,pe+8)[0],'bytes':len(raw),'normalized_sha256':m.sha(m._normalize_fixture_timestamps_for_test(raw)),'data':raw})
  if n==0:time.sleep(1.2)
 a,z=fixture
 fixture_pe=m.strict.PE(a['data']);debug_off=fixture_pe.at(fixture_pe.dirs[6][0],28)
 diffs=[i for i,(x,y) in enumerate(zip(a['data'],z['data'])) if x!=y]
 allowed=set(range(0x80,0x84))|set(range(debug_off+4,debug_off+8))
 assert a['timestamp']!=z['timestamp'] and diffs and all(i in allowed for i in diffs)
 assert m._normalize_fixture_timestamps_for_test(a['data'])==m._normalize_fixture_timestamps_for_test(z['data'])
 checks.append('two real pinned links differ only equal COFF and CodeView timestamps')
 for rec in fixture:del rec['data']
report={'schema':3,'mode':'pe-build-timestamps-v3','pass':True,'checks':len(checks),'cases':checks,'input_sha256':m.sha(b),'normalized_candidate_sha256':m.PINS['official_candidate_sha256'],'mutated_non_timestamp_offsets':mutations,'whole_file_hash_covers_all_other_bytes':True,'fixture':fixture,'fixture_raw_diff_offsets':diffs,'fixture_checked_timestamp_offsets':[0x80,debug_off+4],'fixture_normalized_whole_file_equal':True,'fixture_same_source_output_path_and_command':True,'fixture_stripped_with_actual_pinned_C2_strip_command':True,'fixture_linker_flag':'--exclude-all-symbols matches Wine explicit-export build; both COFF and sole CodeView timestamps remain checked' ,'toolchain':toolchain,'scope':'Host/compiler fixture and transformation only; actual clean Wine/CI build and iPhone canary pending'}
(ROOT/'build/timestamp-tests.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({k:report[k] for k in ('pass','checks','fixture','fixture_raw_diff_offsets','fixture_normalized_whole_file_equal')},indent=2))
