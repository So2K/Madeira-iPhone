#!/usr/bin/env python3
"""MIT. Provenance control flow and atomic transaction units; mocked git explicit."""
from pathlib import Path
import hashlib,importlib.util,json,os,shutil,stat,struct,sys,tempfile
sys.dont_write_bytecode=True
ROOT=Path(__file__).resolve().parents[1]
spec=importlib.util.spec_from_file_location('ci',ROOT/'patch_ntdll_ci.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
BASE=Path(sys.argv[1]);TC=Path(sys.argv[2]).resolve();b=BASE.read_bytes();checks=[]
# Actual toolchain is validated, not supplied as claimed JSON.
actual_toolchain=m.validate_toolchain(TC)
with tempfile.TemporaryDirectory(prefix='provenance-',dir=ROOT/'build') as td:
 d=Path(td);repo=d/'repo';repo.mkdir();(repo/'wine').mkdir()
 for rel in m.PINS['source_files']:
  f=repo/rel;f.parent.mkdir(parents=True,exist_ok=True)
  original=ROOT/'proof/provenance-source-fixture'/rel
  shutil.copyfile(original,f)
 git_calls=[]
 def fake_git(root,*args):
  git_calls.append(args)
  if args==('rev-parse','HEAD'):return m.PINS['wine_gitlink'] if Path(root).name=='wine' else 'a'*40
  if args==('merge-base','--is-ancestor',m.PINS['base_upstream_commit'],'HEAD'):return ''
  if args==('ls-tree','HEAD','wine'):return '160000 commit '+m.PINS['wine_gitlink']+'\twine'
  if args==('status','--porcelain','--untracked-files=no'):return ''
  raise AssertionError(args)
 real_git=m.git;m.git=fake_git
 record=m.validate_provenance(repo,TC)
 assert record['source_head']=='a'*40 and record['source_hashes_computed']==m.PINS['source_files'];checks.append('computed real source/toolchain hashes with explicitly mocked git commands')
 for rel in m.PINS['source_files']:
  f=repo/rel;original=f.read_bytes();f.write_bytes(original+b'\n')
  try:m.validate_provenance(repo,TC)
  except m.GuardError:pass
  else:raise AssertionError('accepted source mutation '+rel)
  f.write_bytes(original);checks.append('refuse changed source '+rel)
 for case in ['root_gitlink','wine_head','wine_dirty','base_not_ancestor']:
  def bad_git(root,*args):
   if case=='root_gitlink' and args==('ls-tree','HEAD','wine'):return '160000 commit '+'b'*40+'\twine'
   if case=='wine_head' and Path(root).name=='wine' and args==('rev-parse','HEAD'):return 'b'*40
   if case=='wine_dirty' and args==('status','--porcelain','--untracked-files=no'):return ' M dlls/ntdll/heap.c'
   if case=='base_not_ancestor' and args[0]=='merge-base':raise m.GuardError('fixture git ancestry refusal')
   return fake_git(root,*args)
  m.git=bad_git
  try:m.validate_provenance(repo,TC)
  except m.GuardError:pass
  else:raise AssertionError(case)
  checks.append('refuse '+case)
 m.git=real_git
 try:m.validate_provenance(d,TC)
 except m.GuardError:pass
 else:raise AssertionError('real nonrepository accepted')
 checks.append('actual git refuses nonrepository')
 for key in m.PINS['toolchain_files']:
  value=m.PINS['toolchain_files'][key]['sha256'];m.PINS['toolchain_files'][key]['sha256']='0'*64
  try:m.validate_toolchain(TC)
  except m.GuardError:pass
  else:raise AssertionError(key)
  m.PINS['toolchain_files'][key]['sha256']=value;checks.append('refuse changed toolchain pin '+key)
 # Positive atomic transaction uses explicitly mocked validated provenance;
 # provenance correctness is exercised separately above, not a full CI claim.
 original_validate=m.validate_provenance;m.validate_provenance=lambda *_:record
 raw=bytearray(b);struct.pack_into('<I',raw,0x80,1);struct.pack_into('<I',raw,0xBA2F4,1);raw=bytes(raw)
 inp=d/'input.dll';inp.write_bytes(raw);inp.chmod(0o640);report=d/'report.json'
 argv=sys.argv[:];sys.argv=['patch_ntdll_ci.py',str(inp),str(inp),'--in-place','--report',str(report),'--repo-root',str(repo),'--toolchain-root',str(TC)]
 m.main();check=m.verify_candidate(inp.read_bytes());assert check['raw_timestamp']==1 and stat.S_IMODE(inp.stat().st_mode)==0o640
 assert not list(d.glob('.oni-ntdll-ci-*'));checks.append('atomic input mode/rawtimestamp/normalizedSHA preserved')
 bad=d/'bad.dll';bad.write_bytes(raw);badreport=d/'bad-report.json';sys.argv=['patch_ntdll_ci.py',str(bad),str(bad),'--in-place','--report',str(badreport),'--repo-root',str(repo),'--toolchain-root',str(TC)]
 def refused_provenance(*_):raise m.GuardError('unit provenance refusal')
 m.validate_provenance=refused_provenance
 try:m.main()
 except m.GuardError:pass
 else:raise AssertionError('provenance refusal ignored')
 assert bad.read_bytes()==raw and not badreport.exists() and not list(d.glob('.oni-ntdll-ci-*'));checks.append('provenance refusal before PE/report/temp mutation')
 sys.argv=argv;m.validate_provenance=original_validate
result={'schema':3,'mode':'pe-build-timestamps-v3','pass':True,'checks':len(checks),'cases':checks,'limitations':['Positive source/git transaction units explicitly mock git answers because full CI checkout is separate','Actual pinned toolchain file hashes and source file bytes are verified','Actual git rejects nonrepository','Full clean Wine/CI build not run here']}
(ROOT/'build/provenance-tests.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
